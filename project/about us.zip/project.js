let parents = document.getElementsByClassName('likedpar')

for (let parent of parents) {
  let fullheart = parent.querySelector('.likedch')
  let append = true

  parent.addEventListener("click", () => {
    if (append) {
      fullheart.remove()

      let newheart = document.createElement('img')
      newheart.src = 'heart.png'
      newheart.style.width = '24px'
      newheart.className = 'likedch'

      parent.appendChild(newheart)
    } else {
      parent.innerHTML = ''
      parent.appendChild(fullheart)
    }

    append = !append
  })
}
